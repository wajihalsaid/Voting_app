dotnet msbuild .\build.msbuild
